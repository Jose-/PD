package decorator.ejemplo;

public class fsd {

}
