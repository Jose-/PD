package poo.biblioteca;

public class Autor extends Ciudadano {

	public Autor(String dni, String nombre, String apellido) {
		super(dni, nombre, apellido);

	}

}
