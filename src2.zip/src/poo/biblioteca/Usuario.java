package poo.biblioteca;

public class Usuario extends Ciudadano {

	public Usuario(String dni, String nombre, String apellido) {
		super(dni, nombre, apellido);
	}

}
