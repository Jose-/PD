package poo.introduccion;

public class Resta {
	public double decrementa(final double valor) {
		return -1;
	}

	public double getDiferencia(final double val1, final double val2) {
		return -1;
	}
}
