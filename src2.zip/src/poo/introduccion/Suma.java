package poo.introduccion;

public class Suma {
public double getSuma(double a, double b) {
return a+b;
}
public double incrementa(double a) {
return ++a;
}
}