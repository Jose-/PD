package poo.alquiler;

public class Moto extends Vehiculo {

	public Moto(int id, String descripcion) {
		super(id, descripcion, 8);
	}

}
