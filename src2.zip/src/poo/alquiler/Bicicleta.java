package poo.alquiler;

public class Bicicleta extends Vehiculo {

	public Bicicleta(int id,String descripcion) {
		super(id,descripcion,2);		
	}
}
