package poo.registrador;

public interface Registrador {

	void registrar(String msg);
}
