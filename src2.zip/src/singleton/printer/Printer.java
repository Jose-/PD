package singleton.printer;

public interface Printer {
	void print(String msg);
}
