package state.red;

public interface Emisor {
    void enviar(String msg);
}
