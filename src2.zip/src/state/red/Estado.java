package state.red;

public enum Estado {
    CERRADO, PARADO, PREPARADO;
}
