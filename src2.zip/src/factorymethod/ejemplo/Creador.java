package factorymethod.ejemplo;

public abstract class Creador {
public abstract Producto crearProducto();
}