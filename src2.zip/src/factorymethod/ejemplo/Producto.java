package factorymethod.ejemplo;

public abstract class Producto {
public abstract void view();
}


