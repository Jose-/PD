package factorymethod.numero;

public abstract class CreadorNumero extends Numero {

	public abstract Numero createNumero();

}
