package visitor.visitor2;

public interface Elemento {
	void aceptar(Visitante v);
}
