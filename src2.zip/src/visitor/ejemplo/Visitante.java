package visitor.ejemplo;

public interface Visitante {
	void visitarElementoA(ElementoA e);

	void visitarElementoB(ElementoB e);
}
