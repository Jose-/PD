package visitor.ejemplo;

public interface Elemento {
	void aceptar(Visitante v);
}
